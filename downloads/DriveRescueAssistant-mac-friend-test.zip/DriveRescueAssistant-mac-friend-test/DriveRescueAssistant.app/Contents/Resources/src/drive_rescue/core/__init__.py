"""Core drive rescue functionality."""
