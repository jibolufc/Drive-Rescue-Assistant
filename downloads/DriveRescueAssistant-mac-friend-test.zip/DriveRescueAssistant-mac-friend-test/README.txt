Drive Rescue Assistant - Friend Test Build

Open FRIEND_TEST_GUIDE.md first.

If macOS blocks the app because it is not yet notarized:
right-click DriveRescueAssistant.app, choose Open, then confirm.

This early build is for testing only.
